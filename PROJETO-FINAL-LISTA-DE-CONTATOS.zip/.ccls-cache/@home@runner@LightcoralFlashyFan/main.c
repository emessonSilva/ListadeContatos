#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_NOME 50
#define MAX_EMAIL 50
#define MAX_TELEFONE 15
#define MAX_CONTATOS 100

typedef struct {
    char nome[MAX_NOME];
    char email[MAX_EMAIL];
    char telefone[MAX_TELEFONE];
} Contato;

void cadastrarContato(Contato contatos[], int numContatos) {
    if (numContatos >= MAX_CONTATOS) {
        printf("A lista de contatos está cheia.\n");
        return;
    }

    Contato novoContato;

    printf("Digite o nome: ");
    fgets(novoContato.nome, MAX_NOME, stdin);
    novoContato.nome[strcspn(novoContato.nome, "\n")] = '\0';

    printf("Digite o email: ");
    fgets(novoContato.email, MAX_EMAIL, stdin);
    novoContato.email[strcspn(novoContato.email, "\n")] = '\0';

    printf("Digite o telefone: ");
    fgets(novoContato.telefone, MAX_TELEFONE, stdin);
    novoContato.telefone[strcspn(novoContato.telefone, "\n")] = '\0';

    contatos[numContatos] = novoContato;

    printf("Contato cadastrado com sucesso!\n");
}

