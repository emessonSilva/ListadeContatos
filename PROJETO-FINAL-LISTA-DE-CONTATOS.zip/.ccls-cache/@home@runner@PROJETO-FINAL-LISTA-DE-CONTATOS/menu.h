#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include  "contato.h"

 
  do {
        printf("Escolha uma opção:\n");
        printf("1. Cadastrar novo contato\n");
        printf("2. Listar contatos\n");
        printf("3. Atualizar contato\n");
        printf("4. Excluir contato\n");
        printf("5. Sair\n");
        printf("Opção: ");
        scanf("%d", &opcao);
        getchar();

        switch (opcao) {
            case 1:
                cadastrarContato(contatos, numContatos);
                numContatos++;
                break;
            case 2:
                listarContatos(contatos, numContatos);
                break;
            case 3:
                atualizarContato(contatos, numContatos);
                break;
            case 4:
                excluirContato(contatos, &numContatos);
                break;
            case 5:
                printf("Encerrando o programa...\n");
                break;
            default:
                printf("Opção inválida.\n");
                break;
        }

        printf("\n");
    } while (opcao != 5);

    return 0;
}