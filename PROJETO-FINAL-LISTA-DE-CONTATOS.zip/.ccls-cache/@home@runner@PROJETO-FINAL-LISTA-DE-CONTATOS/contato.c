#ifndef CONTATO_H
#define CONTATO_H

#define MAX_NOME 50
#define MAX_EMAIL 50
#define MAX_TELEFONE 15
#define MAX_CONTATOS 10

typedef struct {
    char nome[MAX_NOME];
    char email[MAX_EMAIL];
    char telefone[MAX_TELEFONE];
} Contato;

void cadastrarContato(Contato contatos[], int numContatos);

#endif