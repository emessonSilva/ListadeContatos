//Serve para mudar a cor da letra e a cor do fundo

#define RESET "\x1b[0m"

#define PRETO "\x1B[30m"
#define VERMELHO "\x1b[31m"
#define VERDE "\x1b[32m"
#define AMARELO "\x1B[33m"
#define AZUL "\x1B[34m"
#define MAGENTA "\x1B[35m"
#define CIANO "\x1B[36m"
#define BRANCO "\x1B[37m"

#define FUNDO_PRETO "\x1B[40m"
#define FUNDO_VERMELHO "\x1B[41m"
#define FUNDO_VERDE "\x1B[42m"
#define FUNDO_AMARELO "\x1B[43m"
#define FUNDO_AZUL "\x1B[44m"
#define FUNDO_MAGENTA "\x1B[45m"
#define FUNDO_CIANO "\x1B[46m"
#define FUNDO_BRANCO "\x1B[47m"

