#include <stdio.h>

void excluirContato(Contato contatos)