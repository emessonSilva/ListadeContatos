// Bibliotecas usadas para rodar o programa corretamente
#include "cores.h"
#include <stdio.h>

// Criação da função menu
void menu() {
  printf("\n Lista de Contatos    \n\n");
  printf("1. Cadastrar contato\n");
  printf("2. Listar contatos\n");
  printf("3. Atualizar contato\n");
  printf("4. Excluir contato\n");
  printf("5. Sair\n");
  printf("Escolha uma opção: ");
}